import React, { Component } from 'react'
import {Map,GeoJSON} from "react-leaflet"
import countries  from './../Data/2011_Dist.json'
import "leaflet/dist/leaflet.css"
import "./MyMap.css"

class MyMap extends Component {

    componentDidMount(){
        console.log(countries);
    }

    country_style={
        fillColor: "red",
        fillOpacity : 0.1,
    }

    onEachCountry = (country,layer ) =>{
        const country_name=country.properties.NAME_1;
        layer.bindPopup( 
            `${country_name} |
            Utkarsh
            `
        );
        console.log(country);
        //console.log(country.feature.properties.NAME_1);
    }

    render() {
        return (
            <div>
                <h1>My map</h1>
                <Map style={{height:"100vh"}} zoom={4.51} center={[25,85]} > 
                   <GeoJSON  style={this.country_style} data={countries.features} onEachFeature={this.onEachCountry} />
                </Map>
                <h1>Cool</h1>
            </div>
        )
    }
}

export default MyMap
